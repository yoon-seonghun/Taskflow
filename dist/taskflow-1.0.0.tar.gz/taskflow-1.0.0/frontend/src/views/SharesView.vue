<script setup lang="ts">
// 공유 사용자 등록 메뉴 - 추후 구현
</script>

<template>
  <div>
    <h2 class="text-xl font-semibold text-gray-900 mb-4">공유 사용자 등록 메뉴</h2>
    <div class="card">
      <p class="text-gray-500">공유 사용자 목록이 표시됩니다.</p>
    </div>
  </div>
</template>
