/**
 * 댓글 컴포넌트 통합 내보내기
 */

export { default as CommentInput } from './CommentInput.vue'
export { default as CommentList } from './CommentList.vue'
