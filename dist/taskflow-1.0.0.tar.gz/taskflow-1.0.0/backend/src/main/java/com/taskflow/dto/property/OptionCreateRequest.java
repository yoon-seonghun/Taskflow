package com.taskflow.dto.property;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

/**
 * 옵션 생성 요청 DTO
 */
@Getter
@Setter
public class OptionCreateRequest {

    /**
     * 옵션명 (표시값) - DB의 OPTION_LABEL과 매핑
     */
    @NotBlank(message = "옵션명은 필수입니다")
    @Size(max = 100, message = "옵션명은 100자 이내여야 합니다")
    private String optionName;

    /**
     * 표시 색상 (#RRGGBB)
     */
    @Pattern(regexp = "^#[0-9A-Fa-f]{6}$", message = "색상 형식이 올바르지 않습니다 (예: #FF0000)")
    private String color;

    /**
     * 표시 순서
     */
    private Integer sortOrder;
}
